<html>
<head>
</head>
</head>
<body>
<?php
include("connection.php");
if(isset($_POST['submit']))
{

        if($_POST['captcha']==$_POST['ucaptcha']) 
        {
            $fname=$_POST['fname'];
            $lname=$_POST['lname'];
            $email=$_POST['email'];
            $address=$_POST['address'];
            $passwd=$_POST['password'];
            $cpasswd=$_POST['cpassword'];
            if($passwd==$cpasswd)
            {
            $resumen=$_FILES['resume']['name'];
            $resumetmp=$_FILES['resume']['tmp_name'];
            $folder="./resume/".$resumen;
            move_uploaded_file($resumetmp,$folder);
            
            $query="insert into users(firstname,lastname,address,email,resume,password)values('$fname','$lname','$address','$email','$resumen','$passwd')";
            $result=mysqli_query($conn,$query);
            if($result)
            {
            echo "<script>alert('Registration successful!!')</script>";
            echo "Go back to previous page to login.";
            }
            else
            {
                echo "Registration Unsuccessful";
            }
            }
            else
            {
                echo "<script>alert('Your password does not match!!')</script>";
                echo "Go back and reset password";
            }
        }
        else
        {
            echo "<script>alert('captcha dosent match!!')</script>";
            echo "Go to previous page and reset captcha";
        }
}
else
{
    header("Location:form.html");
}
?>

</body>
</html>