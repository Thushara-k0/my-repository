<?php
   session_start();
   include("connection.php");
   if (isset($_SESSION['email']) && isset($_SESSION['id'])) { 
?>

<html>
<head>
<title>Home page</title>
<h2 align="center">User Details</h2>
<style>
table {
    margin: 0 auto;
    font-size:large;
    border: 1px solid black;
}
td{
    border: 1px solid black;

}
th,td{
    font-weight: bold;
    border: 1px solid black;
    padding: 5px;
    text-align: center;
}
td{
    font-weight: lighter;
}
img {
	width: 500px;
	height: 600px;
}
body {
	padding:0px;
}
</style>		
</head>
<body>

<?php 
$email=$_SESSION['email'];
$id=$_SESSION['id'];
$select_query="select * from `users` where email='$email' AND password='$id'";
$result_query=$conn->query($select_query);
while($row=mysqli_fetch_assoc($result_query))
{
	$fname=$row['firstname'];
	$lname=$row['lastname'];
    $address=$row['address'];
    $resume=$row['resume'];
}
echo "<table><tr><td>First Name</td><td>$fname</td></tr><tr><td>Last Name</td><td>$lname</td></tr><tr><td>Address</td><td>$address</td></tr><tr><td>Email</td><td>$email</td></tr><tr><td>Resume</td><td><img  src='./resume/$resume' /></td>
</tr></table>";
?><br>
<center><a href="logout.php">Logout</a></center>
</body>
</html> 
<?php }
else
{
	header("Location: login.html");
}?>
 
