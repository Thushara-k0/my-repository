<?php  
session_start();
include("connection.php");
if (isset($_POST['email']) && isset($_POST['password'])) 
{
	$email = $_POST['email'];
	$password = $_POST['password'];

	if (empty($email)) 
  {
		header("Location: login.php?error=Email  Required");
	}
  else if (empty($password)) 
  {
		header("Location: login.php?error=Password  Required");
	}
  else
  { 
        $sql = "SELECT * FROM users WHERE email='$email' AND password ='$password'";
        $result = mysqli_query($conn, $sql);
        $row=mysqli_num_rows($result);
        if($row==1)
        {
          $_SESSION['email'] = $email;
          $_SESSION['id'] = $password;
          header("Location: homepage.php");
        }
        else 
        {
        	header("Location: login.php?error=Incorect User name or password");
        }
  }

	}
?>
    <!DOCTYPE html>
<html>
  <head>
  <title>Login page</title>
  </head>
  <body>
  <form method="post" action="">
    <table width="30%" style="text-align:center;">
    <tr><td>
      <h1>Login</h1>
        <label>Email id</label>
          <input type="email" name="email"  required><br><br>
        <label>Password</label>
          <input type="password" name="password" id="password" required><br><br>
        <input type="submit" name="submit" value="Login"><br><br>
          Not a member? <a href="form.html">Signup</a>
    </td></tr>
    </table>
      </form>
  </body>
  </html>
 